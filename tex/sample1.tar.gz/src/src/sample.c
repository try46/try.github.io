#include <stdio.h>
int main(int argc, char const *argv[])
{
	printf("Hello,World""\n");
	return 0;
}