platex *.tex
dvipdfmx *.dvi

